﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MedicationList.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DosageForms",
                columns: table => new
                {
                    DosageFormId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DosageForms", x => x.DosageFormId);
                });

            migrationBuilder.CreateTable(
                name: "DrugClasses",
                columns: table => new
                {
                    DrugClassId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DrugClasses", x => x.DrugClassId);
                });

            migrationBuilder.CreateTable(
                name: "Routes",
                columns: table => new
                {
                    RouteId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Routes", x => x.RouteId);
                });

            migrationBuilder.CreateTable(
                name: "Uoms",
                columns: table => new
                {
                    UomId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Uoms", x => x.UomId);
                });

            migrationBuilder.CreateTable(
                name: "Medications",
                columns: table => new
                {
                    MedicationId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DrugClassId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: false),
                    Strength = table.Column<int>(nullable: false),
                    UomId = table.Column<int>(nullable: false),
                    DosageFormId = table.Column<int>(nullable: false),
                    RouteId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medications", x => x.MedicationId);
                    table.ForeignKey(
                        name: "FK_Medications_DosageForms_DosageFormId",
                        column: x => x.DosageFormId,
                        principalTable: "DosageForms",
                        principalColumn: "DosageFormId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Medications_DrugClasses_DrugClassId",
                        column: x => x.DrugClassId,
                        principalTable: "DrugClasses",
                        principalColumn: "DrugClassId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Medications_Routes_RouteId",
                        column: x => x.RouteId,
                        principalTable: "Routes",
                        principalColumn: "RouteId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Medications_Uoms_UomId",
                        column: x => x.UomId,
                        principalTable: "Uoms",
                        principalColumn: "UomId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "DosageForms",
                columns: new[] { "DosageFormId", "Name" },
                values: new object[,]
                {
                    { 1, "Capsule" },
                    { 2, "MDI" },
                    { 3, "Tablet" },
                    { 4, "Vial" }
                });

            migrationBuilder.InsertData(
                table: "DrugClasses",
                columns: new[] { "DrugClassId", "Name" },
                values: new object[,]
                {
                    { 4, "NSAID" },
                    { 3, "Inhaled Corticosteroid" },
                    { 5, "Statin" },
                    { 1, "ACE Inhibitor" },
                    { 2, "Beta Blocker" }
                });

            migrationBuilder.InsertData(
                table: "Routes",
                columns: new[] { "RouteId", "Name" },
                values: new object[,]
                {
                    { 1, "Inhalation" },
                    { 2, "Intramuscular" },
                    { 3, "Oral" },
                    { 4, "Subcutaneous" }
                });

            migrationBuilder.InsertData(
                table: "Uoms",
                columns: new[] { "UomId", "Name" },
                values: new object[,]
                {
                    { 3, "mL" },
                    { 1, "mcg" },
                    { 2, "mg" },
                    { 4, "units" }
                });

            migrationBuilder.InsertData(
                table: "Medications",
                columns: new[] { "MedicationId", "DosageFormId", "DrugClassId", "Name", "RouteId", "Strength", "UomId" },
                values: new object[,]
                {
                    { 3, 2, 3, "Flovent", 1, 110, 1 },
                    { 1, 3, 1, "Lisinopril", 3, 40, 2 },
                    { 2, 1, 1, "Ramipril", 3, 5, 2 },
                    { 4, 3, 4, "Naproxen", 3, 500, 2 },
                    { 5, 3, 5, "Atorvastatin", 3, 40, 2 },
                    { 6, 3, 5, "Simvastatin", 3, 40, 2 },
                    { 7, 3, 2, "Metoprolol XR", 3, 25, 2 },
                    { 8, 3, 2, "Carvedilol", 3, 25, 2 },
                    { 9, 3, 2, "Atenolol", 3, 25, 2 },
                    { 10, 3, 4, "Meloxicam", 3, 15, 2 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Medications_DosageFormId",
                table: "Medications",
                column: "DosageFormId");

            migrationBuilder.CreateIndex(
                name: "IX_Medications_DrugClassId",
                table: "Medications",
                column: "DrugClassId");

            migrationBuilder.CreateIndex(
                name: "IX_Medications_RouteId",
                table: "Medications",
                column: "RouteId");

            migrationBuilder.CreateIndex(
                name: "IX_Medications_UomId",
                table: "Medications",
                column: "UomId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Medications");

            migrationBuilder.DropTable(
                name: "DosageForms");

            migrationBuilder.DropTable(
                name: "DrugClasses");

            migrationBuilder.DropTable(
                name: "Routes");

            migrationBuilder.DropTable(
                name: "Uoms");
        }
    }
}
