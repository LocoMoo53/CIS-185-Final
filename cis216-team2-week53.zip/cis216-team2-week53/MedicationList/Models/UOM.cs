﻿/*******************************************************************
 * Team 2: Jason Thomas | Travis Johnson
 * 12-7-2020
 * "Final Project (Team)"
 * "complete a CRUD MVC ASP.NET core application"
 *******************************************************************/

namespace MedicationList.Models
{
    public class Uom
    {
        public int UomId { get; set; } // Create UoM ID property
        public string Name { get; set; } // Create property for UoM name
    }
}