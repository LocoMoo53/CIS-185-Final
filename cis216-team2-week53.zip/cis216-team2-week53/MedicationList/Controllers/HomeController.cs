﻿/*******************************************************************
 * Team 2: Jason Thomas | Travis Johnson
 * 12-7-2020
 * "Final Project (Team)"
 * "complete a CRUD MVC ASP.NET core application"
 *******************************************************************/

using Microsoft.AspNetCore.Mvc;
using MedicationList.Models; // Using directive for medication list models

namespace MedicationList.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(); // return Home/Index view
        }

        [Route("[action]")]
        public IActionResult About() // return Home/About view
        {
            return View();
        }
    }
}